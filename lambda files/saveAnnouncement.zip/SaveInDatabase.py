import boto3
import datetime
from generateKey import key_gen

class SaveData:
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('AnnouncementTable')
    x = datetime.datetime.now()
    
    def save(self, body):
        self.table.put_item(Item={
                  'id': key_gen(),
                  'title': body['data']['title'],
                  'description': body['data']['desc'],
                  'date': self.x.strftime("%Y")+"-"+self.x.strftime("%m")+"-"+self.x.strftime("%d")
              })
    