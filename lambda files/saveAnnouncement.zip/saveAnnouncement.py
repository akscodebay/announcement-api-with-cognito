import json
import logging
from httpResponses import Responses
from SaveInDatabase import SaveData

response = Responses()

saveData = SaveData()

API_VERSION = 1

def lambda_handler(event, context):
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    try:
        if int(event['headers']['Api-Version']) != API_VERSION:
            return response.errorResponse(context.aws_request_id, 400,"INVALID_API_VERSION","Invalid Api Version")
    except Exception as e:
        logging.info(e)
        return response.errorResponse(context.aws_request_id, 400,"INVALID_API_VERSION","Invalid Api Version")
    
    body = json.loads(event['body'])
    
    try:
        saveData.save(body)
    except Exception as e:
        logging.error(e)
        return response.errorResponse(context.aws_request_id, 500,"SERVER_ERROR","Server error")
    return response.successResponse(context.aws_request_id, 201,"CREATED","Created")
