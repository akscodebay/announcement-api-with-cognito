from random import choice
from string import ascii_letters, digits

def key_gen():
    KEY_LEN = 20
    keylist = [choice(ascii_letters+digits) for i in range(KEY_LEN)]
    return ("".join(keylist))