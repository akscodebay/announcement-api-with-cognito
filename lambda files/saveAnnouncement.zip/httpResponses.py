class Responses:
    def errorResponse(self, requestId, status, code, title="Bad_Request"):
        return { "isBase64Encoded": True,
            "statusCode": status,
            "headers": {},
            "body": "{ \"errors\": [ { \"id\": \""+requestId+"\", \"status\": \""+str(status)+"\", \"code\": \""+code+"\", \"title\":\""+title+"\" } ] }"
        }
    
    def successResponse(self, requestId, status, code, title="Bad_Request"):
        return { "isBase64Encoded": True,
            "statusCode": status,
            "headers": {},
            "body": "{ \"data\": [ { \"id\": \""+requestId+"\", \"status\": \""+str(status)+"\", \"code\": \""+code+"\", \"title\":\""+title+"\" } ] }"
        }