import json
import boto3
from httpResponses import Responses

class GetAnnouncements:
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('AnnouncementTable')
    responses = Responses()
    
    def get(self, pageNo, aws_request_id):
        self.LIMIT = 10
        response = self.table.scan(Limit=self.LIMIT)
        self.pageNo = pageNo
        if response['Count'] == 0:
            return self.responses.errorResponse(aws_request_id, 404,"NOT_FOUND","Not Found")
        pageNo-=1
        
        if pageNo > 0:
            while 'LastEvaluatedKey' in response:
                key = response['LastEvaluatedKey']
                response = self.table.scan(Limit=self.LIMIT, ExclusiveStartKey=key)
                pageNo-=1
                if pageNo == 0:
                    break
                
        if pageNo > 0:
            return self.responses.errorResponse(aws_request_id, 404,"NOT_FOUND","Not Found")
        else:
            return self.responses.ok_Success(self.pageNo, self.LIMIT, response['Count'], json.dumps(response['Items']))