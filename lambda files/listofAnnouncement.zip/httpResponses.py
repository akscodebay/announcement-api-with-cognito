class Responses:
    def errorResponse(self, requestId, status, code, title="Bad_Request"):
        return { "isBase64Encoded": True,
            "statusCode": status,
            "headers": {},
            "body": "{ \"errors\": [ { \"id\": \""+requestId+"\", \"status\": \""+str(status)+"\", \"code\": \""+code+"\", \"title\":\""+title+"\" } ] }"
        }
    
    def ok_Success(self, pageNo, limit, count, data=""):
        return { "isBase64Encoded": True,
            "statusCode": 200,
            "headers": {},
            "body": "{\"data\":"+ data +",\"meta\":{\"pageSize\":\""+str(limit)+"\", \"currentPage\":\""+str(pageNo)+"\",\"itemCount\":\""+str(count)+"\"}}"
        }
        
    
