import logging
from httpResponses import Responses
from getAnnouncements import GetAnnouncements

getAnnouncement = GetAnnouncements()
responses = Responses()

API_VERSION = 1

def lambda_handler(event, context):
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    try:
        if int(event['headers']['Api-Version']) != API_VERSION:
            return responses.errorResponse(context.aws_request_id, 400,"INVALID_API_VERSION","Invalid Api Version")
    except Exception as e:
        logging.info(e)
        return responses.errorResponse(context.aws_request_id, 400,"INVALID_API_VERSION","Invalid Api Version")
    try:
        pageNo = int(event['queryStringParameters']['pageNo'])
    except Exception as e:
        logging.info(e)
        return responses.errorResponse(context.aws_request_id, 400,"INVALID_PARAMETER_VALUE","Input validation error - invalid parameter value")
    
    try:
        return getAnnouncement.get(pageNo, context.aws_request_id)
    except Exception as e:
        logging.error(e)
        return responses.errorResponse(context.aws_request_id, 500,"SERVER_ERROR","Server Error")
    
    